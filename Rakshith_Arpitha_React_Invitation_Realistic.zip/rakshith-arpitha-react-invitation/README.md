# Rakshith & Arpitha — React Wedding Invitation

A Vite + React project converted from the supplied animated HTML invitation.

## Requirements
- Node.js 20.19+ or 22.12+
- npm

## Run locally

```bash
npm install
npm run dev
```

Open the local URL printed by Vite.

## Create a production build

```bash
npm run build
npm run preview
```

The deployable website is generated in `dist/`.

## Project structure

- `src/App.jsx` — React application composition and lifecycle for the invitation engine.
- `src/components/PeacockIntro.jsx` — peacock opening and couple-photo reveal scene.
- `src/components/CelebrationScene.jsx` — elephant welcome, event details, venue and blessings scene.
- `src/components/BackgroundMusic.jsx` — embedded instrumental audio element.
- `src/components/GlobalEffects.jsx` — SVG symbol definitions and ambient canvas.
- `src/invitation.css` — original responsive styling and animations.
- `public/invitation.js` — original canvas animation and interaction engine, including first-interaction music playback.
- `src/components/markup/` — preserved HTML/SVG artwork fragments used by the React components.

## Notes
The conversion keeps the refreshed visual artwork, couple photo, QR code, venue link, event dates, animations and embedded instrumental. React now owns the application composition and component boundaries. The original imperative canvas animation engine is isolated as a static script to preserve the detailed peacock and elephant drawing behavior without changing the visual result.

The music starts on the first genuine user interaction because mobile browsers generally block audible autoplay before a user gesture.

## Photorealistic wildlife assets

- `public/images/peacock-realistic.png` — generated transparent peacock artwork used in the opening reveal.
- `public/images/elephant-realistic.png` — generated transparent decorated elephant artwork used as a mirrored royal welcome pair.

The existing invitation details, embedded couple photo, venue QR code, map link, and instrumental audio are retained.


## Royal animation refresh
- The opening now cross-fades from a walking, closed-tail peacock cutout to the full-fan peacock artwork before the couple portrait is revealed.
- The elephant procession uses a layered image treatment: the lower-leg region and trunk/garland region have independent CSS motion overlays, while the bodies remain largely anchored.
- The visual theme adds emerald brocade-inspired textures, antique-gold borders, warm palace lighting, and refined invitation framing.

## Cinematic sound effects

The invitation plays sound effects after the visitor's first touch/click, as required by mobile-browser audio autoplay policies. Peacock call is from SFXMint (CC0 1.0): https://sfxmint.com/sounds/peacock-calls-08. Elephant slow footfalls, trumpet, and rumble are from Casper's Sidekick sound-effects library: https://www.casper.tw/sound-effects/elephant/ (commercial and app use permitted; credit optional). The effects are loaded from their source URLs, so visitors need an internet connection for these sound effects. Existing background music remains separate.


## Start screen and audio

The invitation now opens on a dedicated royal start screen. The visitor must tap **Start the invitation** before the peacock animation, background music, or animal sound effects begin. This explicit user gesture is designed for Android and iOS browser autoplay restrictions. The existing sound effects are loaded from their configured remote audio URLs, so an internet connection is required for those effects.
