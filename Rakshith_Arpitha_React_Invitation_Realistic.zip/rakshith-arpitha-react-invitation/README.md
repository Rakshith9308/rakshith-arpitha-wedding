# Rakshith & Arpitha — React Wedding Invitation

A Vite + React project converted from the supplied animated HTML invitation.

## Requirements
- Node.js 20.19+ or 22.12+
- npm

## Run locally

```bash
npm install
npm run dev
```

Open the local URL printed by Vite.

## Create a production build

```bash
npm run build
npm run preview
```

The deployable website is generated in `dist/`.

## Project structure

- `src/App.jsx` — React application composition and lifecycle for the invitation engine.
- `src/components/PeacockIntro.jsx` — peacock opening and couple-photo reveal scene.
- `src/components/CelebrationScene.jsx` — elephant welcome, event details, venue and blessings scene.
- `src/components/BackgroundMusic.jsx` — embedded instrumental audio element.
- `src/components/GlobalEffects.jsx` — SVG symbol definitions and ambient canvas.
- `src/invitation.css` — original responsive styling and animations.
- `public/invitation.js` — original canvas animation and interaction engine, including first-interaction music playback.
- `src/components/markup/` — preserved HTML/SVG artwork fragments used by the React components.

## Notes
The conversion keeps the refreshed visual artwork, couple photo, QR code, venue link, event dates, animations and embedded instrumental. React now owns the application composition and component boundaries. The original imperative canvas animation engine is isolated as a static script to preserve the detailed peacock and elephant drawing behavior without changing the visual result.

The music starts on the first genuine user interaction because mobile browsers generally block audible autoplay before a user gesture.

## Photorealistic wildlife assets

- `public/images/peacock-realistic.png` — generated transparent peacock artwork used in the opening reveal.
- `public/images/elephant-realistic.png` — generated transparent decorated elephant artwork used as a mirrored royal welcome pair.

The existing invitation details, embedded couple photo, venue QR code, map link, and instrumental audio are retained.
