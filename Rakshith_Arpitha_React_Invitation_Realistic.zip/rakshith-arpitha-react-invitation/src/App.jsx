import React, { useEffect, useState } from 'react';
import GlobalEffects from './components/GlobalEffects.jsx';
import BackgroundMusic from './components/BackgroundMusic.jsx';
import PeacockIntro from './components/PeacockIntro.jsx';
import CelebrationScene from './components/CelebrationScene.jsx';

/** Loads the existing animation/interaction engine after React mounts the scenes. */
function InvitationEngine() {
  useEffect(() => {
    document.documentElement.classList.add('js');
    const script = document.createElement('script');
    script.src = `${import.meta.env.BASE_URL}invitation.js`;
    script.async = false;
    document.body.appendChild(script);

    return () => {
      script.remove();
    };
  }, []);
  return null;
}

export default function App() {
  const [started, setStarted] = useState(false);

  function beginInvitation() {
    // A real button click unlocks audio on Android/iOS before the animation begins.
    document.dispatchEvent(new Event('wedding-start'));
    setStarted(true);
  }

  return <>
    {!started && <div className="start-screen" role="dialog" aria-modal="true" aria-labelledby="start-title">
      <div className="start-card">
        <span className="start-monogram" aria-hidden="true">R <i>&amp;</i> A</span>
        <p className="start-kicker">A royal celebration awaits</p>
        <h1 id="start-title">Rakshith <span>&amp;</span> Arpitha</h1>
        <p className="start-date">9 &amp; 10 December 2026</p>
        <button className="start-button" type="button" onClick={beginInvitation}>
          <span aria-hidden="true">✧</span> Start the invitation <span aria-hidden="true">✧</span>
        </button>
        <p className="start-hint">Tap to begin with music and sound effects</p>
      </div>
    </div>}
    <GlobalEffects />
    <BackgroundMusic />
    <main>
      <PeacockIntro />
      <CelebrationScene />
    </main>
    <InvitationEngine />
  </>;
}
