// Single source of truth for wedding details and asset URLs.
// Asset URLs use import.meta.env.BASE_URL so they work under a GitHub Pages sub-path.
const B = import.meta.env.BASE_URL;

export const DETAILS = {
  groom: 'Rakshith',
  bride: 'Arpitha',
  reception: { title: 'Reception', date: '9 December 2026', time: '6:30 PM onwards' },
  muhurtha: { title: 'Muhurtha', date: '10 December 2026', time: '8:00 AM onwards' },
  venue: { name: 'AB Convention Hall', place: 'Halebairohalli, Bengaluru' },
  mapsUrl: 'https://maps.app.goo.gl/hAr2E81EuUbveyiEA?g_st=ac',
};

export const IMG = {
  peacockFan: `${B}images/peacock-realistic.png`,
  elephant: `${B}images/elephant-realistic.png`,
  couple: `${B}images/couple.jpg`,
  qr: `${B}images/venue-qr.png`,
};

// Each effect lists sources in priority order: the bundled local file first, then the
// remote library the project already used. A missing source is skipped silently.
export const FILE_SFX = {
  peacock: { volume: 0.55, sources: [`${B}audio/peacock-call.mp3`, 'https://sfxmint.com/dl/peacock-calls-08.mp3'] },
  trumpet: { volume: 0.5, sources: [`${B}audio/elephant-trumpet.mp3`, 'https://sound-effects.casper.tw/audio/animal-elephant-trumpetblast.f480d5a4.mp3'] },
  rumble: { volume: 0.4, sources: [`${B}audio/elephant-rumble.mp3`, 'https://sound-effects.casper.tw/audio/animal-elephant-lowrumble.a7fcf9a1.mp3'] },
};
export const MUSIC = { src: `${B}audio/background.mp3`, volume: 0.4, duckedVolume: 0.2 };
