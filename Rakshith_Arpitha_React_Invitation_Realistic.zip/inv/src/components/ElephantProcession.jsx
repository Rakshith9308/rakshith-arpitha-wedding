import React from 'react';
import { IMG } from '../config.js';
import { Garland } from './Ornament.jsx';

/** Two decorated elephants enter from opposite sides and meet; a garland is presented between them. */
export default function ElephantProcession({ phase }) {
  return (
    <section className={`scene elephants ph-${phase}`} aria-label="Two decorated elephants welcome the guests">
      <header className="scene-top">
        <p className="kn" lang="kn">ಸ್ವಾಗತ</p>
        <h2 className="names small">Welcome</h2>
      </header>
      <div className="garden" aria-hidden="true"><div className="arches" /><div className="lawn" /></div>
      <div className="ele-stage">
        <div className="ele left"><div className="sway"><img src={IMG.elephant} alt="" decoding="async" /></div></div>
        <div className="ele right"><div className="sway"><img src={IMG.elephant} alt="" decoding="async" /></div></div>
        <Garland className="presented" />
      </div>
    </section>
  );
}
