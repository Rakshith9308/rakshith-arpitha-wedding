import React, { useEffect, useRef } from 'react';
import { IMG } from '../config.js';

const BEADS = 24;
// Where the garland is tied on each elephant's trunk, as a fraction of its image box
// (measured on the artwork; the right elephant is mirrored so x is flipped).
const ATTACH_X = 0.86;
const ATTACH_Y = 0.62;

const ease = (t) => 1 - Math.pow(1 - t, 3);

/**
 * Two decorated elephants enter from opposite sides, each holding one end of a flower garland.
 * The garland is drawn every frame between the two trunk attachment points measured from the
 * actual on-screen elephant boxes, so it stays attached while they walk, sags as they close in,
 * and lifts when they present it.
 */
export default function ElephantProcession({ phase }) {
  const stageRef = useRef(null);
  const leftRef = useRef(null);
  const rightRef = useRef(null);
  const stringRef = useRef(null);
  const beadRefs = useRef([]);
  const phaseRef = useRef(phase);
  const presentAt = useRef(null);

  useEffect(() => {
    phaseRef.current = phase;
    if (phase === 'present' && presentAt.current == null) presentAt.current = performance.now();
  }, [phase]);

  useEffect(() => {
    let raf = 0;
    const tick = (now) => {
      const stage = stageRef.current, L = leftRef.current, R = rightRef.current;
      if (stage && L && R) {
        const s = stage.getBoundingClientRect();
        const a = L.getBoundingClientRect();
        const b = R.getBoundingClientRect();
        const raise = presentAt.current == null ? 0 : ease(Math.min(1, (now - presentAt.current) / 1700));
        const x1 = a.left - s.left + a.width * ATTACH_X;
        const x2 = b.left - s.left + b.width * (1 - ATTACH_X);
        const y1 = a.top - s.top + a.height * ATTACH_Y - raise * a.height * 0.16;
        const y2 = b.top - s.top + b.height * ATTACH_Y - raise * b.height * 0.16;
        const d = Math.abs(x2 - x1);
        const len = s.width * 0.46 * (1 - 0.18 * raise);
        const sway = Math.sin(now / 520) * 2 * (0.4 + raise);
        const sag = Math.sqrt(Math.max(0, len * len - d * d)) * 0.5 + sway;
        const cx = (x1 + x2) / 2;
        const cy = (y1 + y2) / 2 + 2 * sag;
        const r = Math.max(7, s.width * 0.021);
        if (stringRef.current) stringRef.current.setAttribute('d', `M${x1} ${y1} Q${cx} ${cy} ${x2} ${y2}`);
        for (let i = 0; i < BEADS; i++) {
          const g = beadRefs.current[i];
          if (!g) continue;
          const t = i / (BEADS - 1), u = 1 - t;
          const x = u * u * x1 + 2 * u * t * cx + t * t * x2;
          const y = u * u * y1 + 2 * u * t * cy + t * t * y2;
          g.setAttribute('transform', `translate(${x.toFixed(1)} ${y.toFixed(1)}) scale(${(r / 10).toFixed(3)})`);
        }
      }
      raf = requestAnimationFrame(tick);
    };
    raf = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(raf);
  }, []);

  return (
    <section className={`scene elephants ph-${phase}`} aria-label="Two decorated elephants welcome the guests with a flower garland">
      <header className="scene-top">
        <p className="kn" lang="kn">ಸ್ವಾಗತ</p>
        <h2 className="names small">Welcome</h2>
      </header>
      <div className="garden" aria-hidden="true"><div className="arches" /><div className="lawn" /></div>
      <div className="ele-stage" ref={stageRef}>
        <div className="ele left" ref={leftRef}><div className="sway"><img src={IMG.elephant} alt="" decoding="async" /></div></div>
        <div className="ele right" ref={rightRef}><div className="sway"><img src={IMG.elephant} alt="" decoding="async" /></div></div>
        <svg className="carried" aria-hidden="true">
          <path ref={stringRef} fill="none" stroke="#2f6b46" strokeWidth="3" strokeLinecap="round" />
          {Array.from({ length: BEADS }, (_, i) => (
            <g key={i} ref={(el) => { beadRefs.current[i] = el; }}>
              {i % 2 === 0 ? (
                <><circle r="10" fill="#e8921a" /><circle r="6" fill="#f7b733" /><circle r="2.2" fill="#b05a00" /></>
              ) : (
                <><circle r="7.4" fill="#fbf6ea" /><circle r="2.8" fill="#efe2bd" /></>
              )}
            </g>
          ))}
        </svg>
      </div>
    </section>
  );
}
