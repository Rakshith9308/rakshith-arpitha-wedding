import React from 'react';
import { DETAILS } from '../config.js';
import { Divider } from './Ornament.jsx';

export default function WelcomeScreen({ onStart, busy }) {
  return (
    <section className="welcome" aria-labelledby="w-title">
      <div className="welcome-frame">
        <p className="kn" lang="kn">|| ಶ್ರೀ ಗಣೇಶಾಯ ನಮಃ ||</p>
        <div className="monogram" aria-hidden="true"><span>R</span><i>&amp;</i><span>A</span></div>
        <p className="kicker">Together with our families</p>
        <h1 id="w-title" className="names">{DETAILS.groom} <em>&amp;</em> {DETAILS.bride}</h1>
        <Divider />
        <p className="invite-title">Wedding Invitation</p>
        <p className="dates">9 &amp; 10 December 2026</p>
        <button type="button" className="start-btn" onClick={onStart} disabled={busy} aria-busy={busy}>
          <span className="start-shine" aria-hidden="true" />
          {busy ? 'Opening the invitation…' : 'Start the Invitation'}
        </button>
        <p className="hint">Turn up your volume for the full experience</p>
      </div>
    </section>
  );
}
