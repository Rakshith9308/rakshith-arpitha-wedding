import React, { useMemo } from 'react';

/** Lightweight drifting petals / light motes (CSS only, ~14 elements). */
export default function Petals() {
  const items = useMemo(() => Array.from({ length: 14 }, (_, i) => ({
    left: `${(i * 73) % 100}%`,
    dur: `${14 + (i * 7) % 9}s`,
    delay: `${-((i * 5) % 16)}s`,
    size: `${8 + (i * 3) % 9}px`,
    kind: i % 3,
  })), []);
  return (
    <div className="petals" aria-hidden="true">
      {items.map((p, i) => (
        <span key={i} className={`petal k${p.kind}`} style={{ left: p.left, animationDuration: p.dur, animationDelay: p.delay, width: p.size, height: p.size }} />
      ))}
    </div>
  );
}
