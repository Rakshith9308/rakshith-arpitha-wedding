import React from 'react';
import { DETAILS } from '../config.js';
import { Divider } from './Ornament.jsx';

function EventCard({ ev, delay }) {
  return (
    <article className="event reveal" style={{ '--d': delay }}>
      <h3>{ev.title}</h3>
      <Divider />
      <p className="ev-date">{ev.date}</p>
      <p className="ev-time">{ev.time}</p>
    </article>
  );
}

export default function WeddingDetails() {
  return (
    <section className="details" aria-label="Wedding details">
      <p className="kicker reveal" style={{ '--d': '0.5s' }}>With the blessings of our families</p>
      <div className="couple-names reveal" style={{ '--d': '0.7s' }}>
        <div><span className="role">Groom</span><span className="who">{DETAILS.groom}</span></div>
        <i>&amp;</i>
        <div><span className="role">Bride</span><span className="who">{DETAILS.bride}</span></div>
      </div>
      <div className="events">
        <EventCard ev={DETAILS.reception} delay="1.1s" />
        <EventCard ev={DETAILS.muhurtha} delay="1.5s" />
      </div>
    </section>
  );
}
