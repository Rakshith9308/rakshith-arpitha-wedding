import React from 'react';
import { DETAILS } from '../config.js';
import { Divider } from './Ornament.jsx';

export default function ClosingScene({ onReplay }) {
  return (
    <footer className="closing reveal" style={{ '--d': '2.6s' }}>
      <Divider />
      <p className="kn" lang="kn">ಶುಭ ವಿವಾಹ</p>
      <p className="blessing">Your presence and blessings will make our celebration complete.</p>
      <p className="signoff">{DETAILS.groom} <em>&amp;</em> {DETAILS.bride}</p>
      <button type="button" className="btn ghost" onClick={onReplay}>Watch the invitation again</button>
    </footer>
  );
}
