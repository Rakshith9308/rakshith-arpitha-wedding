import React from 'react';

export function Divider() {
  return (
    <svg className="divider" viewBox="0 0 300 20" aria-hidden="true">
      <path d="M10 10H125M175 10H290" stroke="currentColor" strokeWidth="1" />
      <path d="M150 2l8 8-8 8-8-8z" fill="none" stroke="currentColor" strokeWidth="1.2" />
      <circle cx="150" cy="10" r="2.2" fill="currentColor" />
      <circle cx="132" cy="10" r="1.6" fill="currentColor" /><circle cx="168" cy="10" r="1.6" fill="currentColor" />
    </svg>
  );
}

/** Marigold + jasmine garland hanging in a swag. Beads are real SVG circles on a curve. */
export function Garland({ className = '', beads = 26 }) {
  const pts = Array.from({ length: beads }, (_, i) => {
    const t = i / (beads - 1);
    const x = 10 + t * 380;
    return { x, y: 10 + Math.sin(Math.PI * t) * 34, i, t };
  });
  return (
    <svg className={`garland ${className}`} viewBox="0 0 400 70" preserveAspectRatio="xMidYMid meet" aria-hidden="true">
      <path d={`M10 10 Q200 78 390 10`} fill="none" stroke="#2f6b46" strokeWidth="3" />
      {pts.map((p) => (
        <g key={p.i} className="bead" style={{ animationDelay: `${p.t * 1.4}s` }}>
          {p.i % 2 === 0 ? (
            <>
              <circle cx={p.x} cy={p.y} r="10" fill="#e8921a" />
              <circle cx={p.x} cy={p.y} r="6.2" fill="#f7b733" />
              <circle cx={p.x} cy={p.y} r="2.2" fill="#b05a00" />
            </>
          ) : (
            <>
              <circle cx={p.x} cy={p.y} r="7.4" fill="#fbf6ea" />
              <circle cx={p.x} cy={p.y} r="2.8" fill="#efe2bd" />
            </>
          )}
        </g>
      ))}
    </svg>
  );
}
