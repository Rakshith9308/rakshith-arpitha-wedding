import React from 'react';
import { IMG } from '../config.js';
import CoupleReveal from './CoupleReveal.jsx';

/**
 * Phases: enter (walks in) -> turn (stops, faces the viewer) -> fan (tail unfurls,
 * revealed feather-by-feather by a sweeping angular mask) -> couple -> exit.
 * NOTE: walking and the fan are built from the supplied still artwork. See README
 * "Limitations" for swapping in true frame-by-frame / WebM animation.
 */
export default function PeacockScene({ phase }) {
  const fanOpen = phase === 'fan' || phase === 'couple';
  const showCouple = phase === 'couple';
  return (
    <section className={`scene peacock ph-${phase}`} aria-label="A peacock opens its feathers in the palace garden">
      <header className="scene-top">
        <p className="kn" lang="kn">|| ಶ್ರೀ ಗಣೇಶಾಯ ನಮಃ ||</p>
        <h2 className="names small">Rakshith <em>&amp;</em> Arpitha</h2>
      </header>
      <div className="garden" aria-hidden="true"><div className="arches" /><div className="lawn" /></div>
      <div className="peacock-stage">
        <div className="walker">
          <div className="bob">
            <img className="pk-walk" src={IMG.peacockWalking} alt="" decoding="async" />
          </div>
        </div>
        <div className={`fan-wrap ${fanOpen ? 'open' : ''}`}>
          <img className="pk-fan" src={IMG.peacockFan} alt="An Indian peacock displaying its iridescent tail" decoding="async" />
        </div>
        <CoupleReveal visible={showCouple} />
      </div>
    </section>
  );
}
