import React from 'react';
import { IMG } from '../config.js';
import CoupleReveal from './CoupleReveal.jsx';

/**
 * ONE peacock image is used for the whole scene (no second bird).
 * enter  -> the bird walks in from the far left of the garden toward the viewer (bobbing, swaying)
 * turn   -> it stops and stands facing the viewer
 * fan    -> its tail feathers unfurl, revealed feather-by-feather by a sweeping angular mask
 * couple -> portrait revealed inside the open fan
 * exit   -> everything fades out
 * The bird is the supplied still artwork, so there are no moving legs (see README).
 */
export default function PeacockScene({ phase }) {
  const fanOpen = phase === 'fan' || phase === 'couple';
  return (
    <section className={`scene peacock ph-${phase}`} aria-label="A peacock walks into the palace garden and opens its feathers">
      <header className="scene-top">
        <p className="kn" lang="kn">|| ಶ್ರೀ ಗಣೇಶಾಯ ನಮಃ ||</p>
        <h2 className="names small">Rakshith <em>&amp;</em> Arpitha</h2>
      </header>
      <div className="garden" aria-hidden="true"><div className="arches" /><div className="lawn" /></div>
      <div className="peacock-stage">
        <div className="walker">
          <div className="bob">
            <div className={`fan-mask ${fanOpen ? 'open' : ''}`}>
              <img className="pk-fan" src={IMG.peacockFan} alt="An Indian peacock displaying its iridescent tail" decoding="async" />
            </div>
          </div>
        </div>
        <CoupleReveal visible={phase === 'couple'} />
      </div>
    </section>
  );
}
