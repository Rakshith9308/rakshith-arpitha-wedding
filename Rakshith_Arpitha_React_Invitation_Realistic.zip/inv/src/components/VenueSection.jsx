import React from 'react';
import { DETAILS, IMG } from '../config.js';
import { Divider } from './Ornament.jsx';

export default function VenueSection() {
  return (
    <section className="venue reveal" style={{ '--d': '2s' }} aria-label="Venue">
      <p className="label">Venue</p>
      <h3>{DETAILS.venue.name}</h3>
      <p className="place">{DETAILS.venue.place}</p>
      <Divider />
      <figure className="qr">
        <img src={IMG.qr} width="200" height="200" alt="QR code that opens the venue location in Google Maps" />
        <figcaption>Scan for directions</figcaption>
      </figure>
      <a className="btn" href={DETAILS.mapsUrl} target="_blank" rel="noopener noreferrer">Open in Google Maps</a>
    </section>
  );
}
