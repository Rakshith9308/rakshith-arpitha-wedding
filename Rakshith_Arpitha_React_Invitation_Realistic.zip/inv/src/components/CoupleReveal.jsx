import React from 'react';
import { IMG } from '../config.js';

/** Arch-shaped golden frame; the portrait is revealed with an expanding circular clip. */
export default function CoupleReveal({ visible }) {
  return (
    <figure className={`couple ${visible ? 'is-on' : ''}`} aria-hidden={!visible}>
      <div className="couple-glow" />
      <div className="couple-frame">
        <img src={IMG.couple} alt="Rakshith and Arpitha" decoding="async" />
      </div>
    </figure>
  );
}
