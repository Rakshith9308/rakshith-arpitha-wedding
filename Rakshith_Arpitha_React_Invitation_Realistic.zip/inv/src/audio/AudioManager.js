import { FILE_SFX, MUSIC } from '../config.js';

/**
 * Central audio manager. All sound in the invitation goes through this class.
 *
 *  - unlock() must be called synchronously from the Start tap. It creates the
 *    AudioContext, starts the music element and primes every effect element.
 *  - Footsteps / rustle / chimes are synthesised into AudioBuffers (no downloads).
 *  - Animal calls are HTMLAudioElements with a source fallback chain.
 *  - One element per effect => replaying can never stack duplicate playback.
 *  - stopEffects() silences everything scene-related; music keeps playing.
 */
export class AudioManager {
  constructor() {
    this.ctx = null;
    this.master = null;
    this.music = null;
    this.files = {};
    this.buffers = {};
    this.muted = false;
    this.unlocked = false;
    this.activeNodes = new Set();
    this.lastStep = 0;
    this.duckTimer = null;
    this.listeners = new Set();
  }

  onChange(fn) { this.listeners.add(fn); return () => this.listeners.delete(fn); }

  /** Call from inside a user gesture handler. Never throws. */
  unlock() {
    if (this.unlocked) { this.ctx?.state === 'suspended' && this.ctx.resume().catch(() => {}); this.music?.play().catch(() => {}); return; }
    this.unlocked = true;
    try {
      const AC = window.AudioContext || window.webkitAudioContext;
      if (AC) {
        this.ctx = new AC();
        this.master = this.ctx.createGain();
        this.master.gain.value = this.muted ? 0 : 1;
        this.master.connect(this.ctx.destination);
        this.ctx.resume().catch(() => {});
        this.buffers = buildSynthBuffers(this.ctx);
      }
    } catch { /* synthesised effects simply stay silent */ }

    try {
      this.music = new Audio(MUSIC.src);
      this.music.loop = true;
      this.music.preload = 'auto';
      this.music.volume = MUSIC.volume;
      this.music.muted = this.muted;
      this.music.playsInline = true;
      this.music.play().catch(() => {});
    } catch { /* ignore */ }

    // Create and prime the file effects inside the gesture so later play() calls are allowed.
    Object.entries(FILE_SFX).forEach(([key, def]) => {
      const el = new Audio();
      el.preload = 'auto';
      el.playsInline = true;
      el.muted = true;
      let i = 0;
      const next = () => { if (i < def.sources.length) { el.src = def.sources[i++]; el.load(); } else el.dataset.dead = '1'; };
      el.addEventListener('error', next);
      next();
      el.play().then(() => { el.pause(); el.currentTime = 0; el.muted = this.muted; }).catch(() => { el.muted = this.muted; });
      this.files[key] = el;
    });
  }

  setMuted(m) {
    this.muted = m;
    if (this.master) this.master.gain.value = m ? 0 : 1;
    if (this.music) this.music.muted = m;
    Object.values(this.files).forEach((el) => { el.muted = m; });
    this.listeners.forEach((fn) => fn(m));
  }
  toggleMute() { this.setMuted(!this.muted); return this.muted; }

  /** Lower the music briefly so animal sounds stay clear, then restore it. */
  duck(ms = 2600) {
    if (!this.music) return;
    clearTimeout(this.duckTimer);
    this.music.volume = MUSIC.duckedVolume;
    this.duckTimer = setTimeout(() => { if (this.music) this.music.volume = MUSIC.volume; }, ms);
  }

  playFile(key, volumeScale = 1) {
    const el = this.files[key];
    const def = FILE_SFX[key];
    if (!el || !def || el.dataset.dead) return; // missing asset: handled gracefully
    try {
      el.pause();
      el.currentTime = 0;
      el.volume = Math.min(1, def.volume * volumeScale);
      el.muted = this.muted;
      el.play().catch(() => {});
      this.duck();
    } catch { /* ignore */ }
  }

  playBuffer(key, volume = 1, rate = 1) {
    if (!this.ctx || !this.buffers[key]) return;
    const src = this.ctx.createBufferSource();
    const g = this.ctx.createGain();
    src.buffer = this.buffers[key];
    src.playbackRate.value = rate;
    g.gain.value = volume;
    src.connect(g).connect(this.master);
    this.activeNodes.add(src);
    src.onended = () => this.activeNodes.delete(src);
    src.start();
  }

  /** Rate-limited so overlapping steps can never pile up. side: 0 | 1 alternates pitch. */
  footstep(side = 0, volume = 0.9) {
    const now = performance.now();
    if (now - this.lastStep < 320) return;
    this.lastStep = now;
    this.playBuffer('step', volume, side ? 0.9 : 1.05);
  }

  peacockCall() { this.playFile('peacock'); }
  trumpet() { this.playFile('trumpet'); }
  rumble() { this.playFile('rumble'); }
  rustle() { this.playBuffer('rustle', 0.7); }
  chime() { this.playBuffer('chime', 0.55); }
  garlandBell() { this.playBuffer('bell', 0.5); }
  swish() { this.playBuffer('swish', 0.4); }

  /** Silence every scene effect (music untouched). */
  stopEffects() {
    Object.values(this.files).forEach((el) => { try { el.pause(); el.currentTime = 0; } catch { /* ignore */ } });
    this.activeNodes.forEach((n) => { try { n.stop(); } catch { /* ignore */ } });
    this.activeNodes.clear();
    clearTimeout(this.duckTimer);
    if (this.music) this.music.volume = MUSIC.volume;
  }

  dispose() {
    this.stopEffects();
    try { this.music?.pause(); } catch { /* ignore */ }
    try { this.ctx?.close(); } catch { /* ignore */ }
    this.listeners.clear();
    this.files = {}; this.buffers = {}; this.music = null; this.ctx = null; this.unlocked = false;
  }
}

/* ---------- synthesised effects ---------- */
function buildSynthBuffers(ctx) {
  const sr = ctx.sampleRate;
  const make = (secs, fn) => {
    const buf = ctx.createBuffer(1, Math.floor(sr * secs), sr);
    const d = buf.getChannelData(0);
    for (let i = 0; i < d.length; i++) d[i] = fn(i / sr, i);
    return buf;
  };
  let seed = 7;
  const rnd = () => { seed = (seed * 16807) % 2147483647; return seed / 2147483647 * 2 - 1; };

  // Heavy, soft footfall: low sine thump + low-passed noise.
  let lp = 0;
  const step = make(0.42, (t) => {
    const thump = Math.sin(2 * Math.PI * (70 - 35 * t) * t) * Math.exp(-t * 11);
    lp += 0.06 * (rnd() - lp);
    return (thump * 0.9 + lp * Math.exp(-t * 14) * 1.4) * 0.8;
  });

  // Feather rustle: band-ish noise with irregular crackle envelope over 2.6s.
  let a = 0, b = 0;
  const rustle = make(2.6, (t) => {
    const n = rnd();
    a += 0.5 * (n - a); b += 0.08 * (a - b);
    const crackle = Math.pow(Math.abs(Math.sin(t * 37) * Math.sin(t * 11.3 + 1)), 3);
    const env = Math.min(1, t / 0.3) * Math.min(1, (2.6 - t) / 0.6);
    return (a - b) * crackle * env * 0.55;
  });

  // Soft musical accent: bell-like partials.
  const bellPartials = (freqs, secs, decay) => make(secs, (t) => {
    let s = 0;
    freqs.forEach((f, i) => { s += Math.sin(2 * Math.PI * f * t) * Math.exp(-t * (decay + i * 0.8)) / (i + 1.4); });
    return s * Math.min(1, t / 0.01) * 0.35;
  });
  const chime = bellPartials([659.25, 987.77, 1318.5, 1975.5], 3.2, 1.4);
  const bell = bellPartials([523.25, 784, 1046.5, 1568], 3.4, 1.2);

  // Trunk / garland swish: short filtered noise sweep.
  let s1 = 0;
  const swish = make(0.7, (t) => {
    s1 += (0.04 + 0.25 * Math.sin(Math.PI * t / 0.7)) * (rnd() - s1);
    return s1 * Math.sin(Math.PI * t / 0.7) * 0.9;
  });

  return { step, rustle, chime, bell, swish };
}
