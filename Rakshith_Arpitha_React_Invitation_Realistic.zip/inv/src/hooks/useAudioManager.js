import { useEffect, useRef, useState } from 'react';
import { AudioManager } from '../audio/AudioManager.js';

/** Creates one AudioManager for the app's lifetime and exposes its mute state. */
export function useAudioManager() {
  const ref = useRef(null);
  if (!ref.current) ref.current = new AudioManager();
  const [muted, setMutedState] = useState(false);

  useEffect(() => {
    const am = ref.current;
    const off = am.onChange(setMutedState);
    return () => { off(); am.dispose(); };
  }, []);

  return { audio: ref.current, muted };
}
