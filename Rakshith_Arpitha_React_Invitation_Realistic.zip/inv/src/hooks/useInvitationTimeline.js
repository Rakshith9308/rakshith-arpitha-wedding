import { useCallback, useEffect, useRef, useState } from 'react';

/**
 * Central scene controller. Every scene change and every sound cue is scheduled
 * here against one timeline, so nothing is timed independently inside a component.
 *
 * scene: welcome | peacock | elephants | final
 * phase: sub-state used by the scene components for their CSS transitions.
 */
const FULL = {
  walkIn: 5600, turn: 900, fan: 4200, couple: 5200, exit: 2600,
  elephantWalk: 7200, present: 4800,
};
const REDUCED = { walkIn: 700, turn: 400, fan: 900, couple: 3600, exit: 900, elephantWalk: 900, present: 2200 };

export function useInvitationTimeline(audio, reducedMotion) {
  const [state, setState] = useState({ scene: 'welcome', phase: 'idle', run: 0 });
  const timers = useRef([]);
  const runRef = useRef(0);

  const clear = useCallback(() => { timers.current.forEach(clearTimeout); timers.current = []; }, []);
  const at = useCallback((ms, fn) => { timers.current.push(setTimeout(fn, ms)); }, []);
  const go = useCallback((scene, phase) => setState((s) => ({ ...s, scene, phase })), []);

  const toFinal = useCallback(() => {
    clear();
    audio.stopEffects();
    go('final', 'show');
  }, [audio, clear, go]);

  const play = useCallback(() => {
    clear();
    audio.stopEffects();
    runRef.current += 1;
    setState({ scene: 'peacock', phase: 'enter', run: runRef.current });
    const D = reducedMotion ? REDUCED : FULL;
    let t = 0;

    // ---- Peacock ----
    at(500, () => audio.peacockCall());
    if (!reducedMotion) at(D.walkIn - 1500, () => audio.peacockCall());
    t += D.walkIn;
    at(t, () => go('peacock', 'turn'));
    t += D.turn;
    at(t, () => { go('peacock', 'fan'); audio.rustle(); });
    t += D.fan;
    at(t, () => { go('peacock', 'couple'); audio.chime(); });
    t += D.couple;
    at(t, () => go('peacock', 'exit'));
    t += D.exit;

    // ---- Elephants ----
    at(t, () => { audio.stopEffects(); go('elephants', 'enter'); audio.trumpet(); });
    at(t + 1500, () => audio.rumble());
    if (!reducedMotion) {
      const stepMs = 640;
      for (let k = 0, s = t + 500; s < t + D.elephantWalk; k++, s += stepMs) at(s, () => audio.footstep(k % 2));
      at(t + 2600, () => audio.swish());
    }
    t += D.elephantWalk;
    at(t, () => { go('elephants', 'present'); audio.swish(); });
    at(t + 500, () => audio.garlandBell());
    at(t + 900, () => audio.trumpet());
    t += D.present;

    // ---- Details / venue / closing live on the final scrolling page ----
    at(t, () => { audio.stopEffects(); go('final', 'show'); });
  }, [audio, at, clear, go, reducedMotion]);

  useEffect(() => clear, [clear]);

  return { ...state, play, skip: toFinal, replay: play };
}
