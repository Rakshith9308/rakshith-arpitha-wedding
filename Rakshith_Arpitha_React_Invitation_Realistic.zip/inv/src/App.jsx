import React, { useCallback, useEffect, useRef, useState } from 'react';
import { IMG } from './config.js';
import { useAudioManager } from './hooks/useAudioManager.js';
import { useInvitationTimeline } from './hooks/useInvitationTimeline.js';
import WelcomeScreen from './components/WelcomeScreen.jsx';
import PeacockScene from './components/PeacockScene.jsx';
import ElephantProcession from './components/ElephantProcession.jsx';
import WeddingDetails from './components/WeddingDetails.jsx';
import VenueSection from './components/VenueSection.jsx';
import ClosingScene from './components/ClosingScene.jsx';
import MuteButton from './components/MuteButton.jsx';
import Petals from './components/Petals.jsx';
import { Garland } from './components/Ornament.jsx';

function usePrefersReducedMotion() {
  const [r, setR] = useState(() => window.matchMedia?.('(prefers-reduced-motion: reduce)').matches ?? false);
  useEffect(() => {
    const mq = window.matchMedia?.('(prefers-reduced-motion: reduce)');
    if (!mq) return undefined;
    const h = (e) => setR(e.matches);
    mq.addEventListener?.('change', h);
    return () => mq.removeEventListener?.('change', h);
  }, []);
  return r;
}

function preload(urls, timeoutMs) {
  const jobs = urls.map((u) => new Promise((res) => {
    const im = new Image();
    im.onload = im.onerror = () => res();
    im.src = u;
    im.decode?.().then(res, res);
  }));
  return Promise.race([Promise.all(jobs), new Promise((res) => setTimeout(res, timeoutMs))]);
}

export default function App() {
  const reduced = usePrefersReducedMotion();
  const { audio, muted } = useAudioManager();
  const tl = useInvitationTimeline(audio, reduced);
  const [busy, setBusy] = useState(false);
  const startedRef = useRef(false);

  // Warm the image cache while the welcome screen is showing.
  useEffect(() => { preload(Object.values(IMG), 8000); }, []);

  const handleStart = useCallback(() => {
    if (startedRef.current) return;          // ignore double taps
    startedRef.current = true;
    audio.unlock();                          // runs inside the tap: unlocks all audio
    setBusy(true);
    // Never wait on assets longer than 2.5s; the tap is already honoured (music is playing).
    preload([IMG.peacockWalking, IMG.peacockFan, IMG.elephant, IMG.couple], 2500).then(() => tl.play());
  }, [audio, tl]);

  const handleReplay = useCallback(() => {
    audio.unlock();
    tl.replay();
  }, [audio, tl]);

  const { scene, phase, run } = tl;
  const started = scene !== 'welcome';

  return (
    <div className={`app scene-${scene} ${reduced ? 'reduced' : ''}`}>
      <div className="bg-silk" aria-hidden="true" />
      {!reduced && scene !== 'welcome' && <Petals />}

      {scene === 'welcome' && <WelcomeScreen onStart={handleStart} busy={busy} />}
      {scene === 'peacock' && <PeacockScene key={`p${run}`} phase={phase} />}
      {scene === 'elephants' && <ElephantProcession key={`e${run}`} phase={phase} />}
      {scene === 'final' && (
        <main className="final" key={`f${run}`}>
          <Garland className="final-garland" />
          <WeddingDetails />
          <VenueSection />
          <ClosingScene onReplay={handleReplay} />
        </main>
      )}

      {started && (
        <>
          <MuteButton muted={muted} onToggle={() => audio.toggleMute()} />
          {scene !== 'final' && <button type="button" className="skip-btn" onClick={tl.skip}>Skip</button>}
        </>
      )}
    </div>
  );
}
