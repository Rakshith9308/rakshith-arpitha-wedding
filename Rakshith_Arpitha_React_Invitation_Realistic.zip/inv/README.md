# Rakshith & Arpitha — Royal Wedding Invitation (React + Vite)

Emerald-and-antique-gold South Indian wedding invitation. Mobile-first (9:16), works on desktop.

## Run / build / deploy
```bash
npm install
npm run dev        # local development
npm run build      # production build -> dist/
npm run preview    # test the production build locally
```
**GitHub Pages:** `vite.config.js` uses `base: './'`, so every asset URL is relative and works under
`https://<user>.github.io/<repo>/`. `.github/workflows/deploy.yml` builds and deploys on every push to `main`
(repo Settings → Pages → Source: *GitHub Actions*).

## Experience (one central timeline: `src/hooks/useInvitationTimeline.js`)
Welcome → **Start** tap (unlocks audio, starts music) → peacock walks in → turns → tail fan unfurls →
couple portrait revealed → fades → two elephants enter from opposite sides, footsteps synced → garland presented →
details / venue + QR + Maps → closing with **Watch again**. A **Skip** button and a **mute** button are always visible.
`prefers-reduced-motion` gets a short, simplified sequence.

## Structure
- `src/config.js` — event details, Maps URL, asset URLs, sound-effect sources (edit here)
- `src/audio/AudioManager.js` — the only place audio is played (unlock, music ducking, mute, rate-limited footsteps, cleanup)
- `src/hooks/` — `useInvitationTimeline` (scenes + sound cues), `useAudioManager`
- `src/components/` — WelcomeScreen, PeacockScene, CoupleReveal, ElephantProcession, WeddingDetails, VenueSection, ClosingScene, MuteButton, Petals, Ornament
- `public/images`, `public/audio` — couple photo, QR code (decodes to the real Maps link), artwork, background music

## Audio
- `public/audio/background.mp3` — your original instrumental (extracted from the old build).
- Footsteps, feather rustle, chime and garland bell are synthesised in the browser (no files, no licence issue).
- Peacock call / elephant trumpet / rumble: the manager tries `public/audio/peacock-call.mp3`, `elephant-trumpet.mp3`,
  `elephant-rumble.mp3` first, then the same remote files the old version used (SFXMint CC0; Casper's Sidekick, credit optional).
  **To work offline, download those three and drop them into `public/audio/` with those names.** Missing files are skipped silently.

## Limitations (please read)
- The peacock and elephants are the three still PNGs from your project. The peacock "walk" is a slide-in with a body bob,
  the tail opens via a feather-by-feather sweeping mask (not a scale/rotate), and the elephants walk in with a weight-shift sway.
  **There are no rigged legs, no independent trunk/ear movement and no trunk-held garland.** The garland is an SVG hung between them.
  Truly realistic cycles need real assets (transparent WebM / PNG sequences / Rive / rigged 3D) — none could be created or downloaded here.
- Fonts load from Google Fonts (fallback serif fonts if offline).
