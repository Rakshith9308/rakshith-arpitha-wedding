import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';

// base './' keeps every asset URL relative, so the build works under any
// GitHub Pages sub-path (https://<user>.github.io/<repo>/) without edits.
export default defineConfig({
  plugins: [react()],
  base: './',
  build: { target: 'es2020', chunkSizeWarningLimit: 800 },
});
