import React, { useEffect } from 'react';
import GlobalEffects from './components/GlobalEffects.jsx';
import BackgroundMusic from './components/BackgroundMusic.jsx';
import PeacockIntro from './components/PeacockIntro.jsx';
import CelebrationScene from './components/CelebrationScene.jsx';

/** Loads the existing animation/interaction engine after React mounts the scenes. */
function InvitationEngine() {
  useEffect(() => {
    document.documentElement.classList.add('js');
    const script = document.createElement('script');
    script.src = `${import.meta.env.BASE_URL}invitation.js`;
    script.async = false;
    document.body.appendChild(script);

    return () => {
      script.remove();
    };
  }, []);
  return null;
}

export default function App() {
  return <>
    <GlobalEffects />
    <BackgroundMusic />
    <main>
      <PeacockIntro />
      <CelebrationScene />
    </main>
    <InvitationEngine />
  </>;
}
