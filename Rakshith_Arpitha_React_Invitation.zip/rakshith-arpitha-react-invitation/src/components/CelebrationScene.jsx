import React from 'react';
import markup from './markup/celebration-scene.html?raw';
import { Markup } from './Markup.jsx';

export default function CelebrationScene() {
  return <Markup html={markup} />;
}
