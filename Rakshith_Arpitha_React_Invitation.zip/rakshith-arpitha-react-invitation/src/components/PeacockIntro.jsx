import React from 'react';
import markup from './markup/peacock-intro.html?raw';
import { Markup } from './Markup.jsx';

export default function PeacockIntro() {
  return <Markup html={markup} />;
}
