import React from 'react';
import symbols from './markup/global-effects.html?raw';
import canvas from './markup/ambient-canvas.html?raw';
import { Markup } from './Markup.jsx';

export default function GlobalEffects() {
  return <>
    <Markup html={symbols} />
    <Markup html={canvas} />
  </>;
}
