import React from 'react';
import audioMarkup from './markup/background-audio.html?raw';
import { Markup } from './Markup.jsx';

export default function BackgroundMusic() {
  return <Markup html={audioMarkup} />;
}
