import React from 'react';

/** Small adapter for preserving the original invitation's detailed SVG/HTML artwork. */
export function Markup({ html, className }) {
  return <div className={className} dangerouslySetInnerHTML={{ __html: html }} />;
}
